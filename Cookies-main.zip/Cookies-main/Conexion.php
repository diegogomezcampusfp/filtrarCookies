<?php
class Conexion{
    public mysqli $conn;

    function __construct($host = 'localhost', $user = 'root', $pass = '', $db = 'test')
    {
        $this->conn= new mysqli($host, $user, $pass, $db);
    }

}