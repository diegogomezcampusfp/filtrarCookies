<!doctype html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/purecss@2.0.6/build/pure-min.css" integrity="sha384-Uu6IeWbM+gzNVXJcM9XV3SohHtmWE+3VGi496jvgX1jyvDTXfdK+rfZc8C1Aehk5" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
require_once ('Conexion.php');
$conexion=new Conexion();
$articulo_buscado = $_GET['articulo'];
setcookie("articulo",$articulo_buscado,0);

if (isset($_GET['borrar'])){
    unset($_COOKIE[0]);
    header('Location: ./articulos.php');
}



$cursor=mysqli_query($conexion->conn,"select * from northwind.products where UnitPrice <= '$articulo_buscado' order by UnitPrice ASC ");
echo "<table class='pure-table'>
        <tr>
        <td >ProductID</td>
        <td>ProductName</td>
        <td>SupplierID</td>
        <td>CategoryID</td>
        <td>QuantityPerUnit</td>
        <td>UnitPrice</td>
        <td>UnitsInStock</td>
        <td>UnitsOnOrder</td>
        <td>ReorderLevel</td>
        <td>Discontinued</td>
     
        </tr>";
while ($fila = $cursor->fetch_row()){
    echo "<tr>
      <td>".$fila[0]."</td>
       <td>".$fila[1]."</td>  
        <td>".$fila[2]."</td>  
         <td>".$fila[3]."</td>
         <td>".$fila[4]."</td>
         <td>".$fila[5]."</td> 
         <td>".$fila[6]."</td> 
         <td>".$fila[7]."</td>
         <td>".$fila[8]."</td> 
         <td>".$fila[9]."</td>       
    </tr>";
}
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>




